package com.sely.launcher.sidebar

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.IBinder
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.AppGridAdapter
import com.sely.launcher.AppRepository
import com.sely.launcher.R
import com.sely.launcher.appmanagement.FavoritesStore
import com.sely.launcher.controlcenter.ControlTile
import com.sely.launcher.controlcenter.ControlTileAdapter
import com.sely.launcher.gamemode.GameModeStore
import com.sely.launcher.multitask.LaunchHistoryStore
import com.sely.launcher.performance.PerformanceModeStore
import com.sely.launcher.theme.ThemeManager
import kotlin.math.abs

/**
 * Sely Smart Sidebar — an OPPO/ColorOS-style edge handle that stays on
 * top of whatever app is running (including a game), drag/tap to open
 * a panel of favorites, real tools, and your own Sely-launch history.
 *
 * Architecture: same real mechanism as FloatingBubbleService (overlay
 * bubble) — `WindowManager` + `TYPE_APPLICATION_OVERLAY`, a foreground
 * service with an ongoing Stop notification. Two independent windows:
 * the small always-on handle (never focusable, so it never steals
 * input from the app underneath) and the panel (focusable only while
 * open, since it has real EditText search).
 *
 * What's real here, tier by tier (project's 🟢/🟡/🔴 convention):
 *  🟢 Favorites — the *same* FavoritesStore App Management already
 *     writes to, with real drag-to-reorder and remove (see
 *     SidebarFavoriteAdapter) — not a sidebar-only copy of the list.
 *  🟢 Flashlight — CameraManager.setTorchMode, same as Control Center.
 *  🟢 Screenshot/Screen Recording/QR Scan/Clipboard — launch Sely's
 *     own real tools for each (no API lets a launcher trigger a
 *     screenshot or a scan directly without a UI).
 *  🟢 Calculator/Camera — real public intents
 *     (`CATEGORY_APP_CALCULATOR`, `INTENT_ACTION_STILL_IMAGE_CAMERA`)
 *     handed to whichever app the user has set for each; if none
 *     resolves, this says so rather than silently failing.
 *  🟡 "Recent" — Sely's own launch history (`LaunchHistoryStore`), the
 *     same honest scope already used by Multitask Hub and Quick
 *     Switch: Android gives no third-party app access to the real
 *     system Recents list.
 *  🟡 Game Mode dimming — there's no API to ask Android "what's in the
 *     foreground right now" either. The handle dims when the
 *     *most-recently-Sely-launched* app is tagged as a game (see
 *     GameModeStore) — a real signal Sely already has, not a live
 *     foreground-app detector.
 */
class SmartSidebarService : Service() {

    companion object {
        const val ACTION_STOP = "com.sely.launcher.sidebar.STOP"
        private const val CHANNEL_ID = "sely_smart_sidebar"
        private const val NOTIF_ID = 9301
    }

    private lateinit var windowManager: WindowManager
    private var handleView: View? = null
    private var panelView: View? = null
    private lateinit var handleParams: WindowManager.LayoutParams
    private var torchOn = false
    private var screenHeightPx = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        screenHeightPx = resources.displayMetrics.heightPixels
        SmartSidebarPrefs.setRunning(this, true)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        if (handleView == null) addHandle()
        return START_STICKY
    }

    // ---------------------------------------------------------------
    // Handle: pinned to the chosen screen edge, draggable vertically,
    // tap or inward-drag opens the panel.
    // ---------------------------------------------------------------
    private fun addHandle() {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_sidebar_handle, null)
        val pill = view.findViewById<View>(R.id.handlePill)
        pill.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 10f * resources.displayMetrics.density
            setColor(ThemeManager.accentColor(this@SmartSidebarService))
        }

        val isRight = SmartSidebarPrefs.isRightEdge(this)
        // Explicit pixel size, NOT WRAP_CONTENT: a WindowManager-added
        // view has no real parent, so WRAP_CONTENT measures against the
        // raw screen bounds. Combined with match_parent anywhere inside
        // (now fixed in the layout too), that produced a handle that
        // filled almost the whole screen instead of a small pill.
        val density = resources.displayMetrics.density
        handleParams = WindowManager.LayoutParams(
            (20 * density).toInt(),
            (56 * density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or if (isRight) Gravity.END else Gravity.START
            x = 0
            y = (SmartSidebarPrefs.getHandleY(this@SmartSidebarService) * screenHeightPx).toInt()
        }
        applyHandleAlpha(view)

        var initialTouchY = 0f
        var initialY = 0
        var draggedVertically = false
        var openedByDrag = false
        val inwardThresholdPx = (36 * resources.displayMetrics.density).toInt()

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialTouchY = event.rawY
                    initialY = handleParams.y
                    draggedVertically = false
                    openedByDrag = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dy) > 8) draggedVertically = true
                    handleParams.y = (initialY + dy).coerceIn(0, (screenHeightPx - view.height).coerceAtLeast(0))
                    windowManager.updateViewLayout(view, handleParams)

                    // "Swipe inward" — how far the touch point has moved
                    // away from the edge, not the handle itself (the
                    // handle stays pinned so it doesn't visually detach).
                    val inwardDistance = if (isRight) {
                        (resources.displayMetrics.widthPixels - event.rawX)
                    } else {
                        event.rawX
                    }
                    if (!openedByDrag && inwardDistance > inwardThresholdPx && panelView == null) {
                        openedByDrag = true
                        openPanel()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    SmartSidebarPrefs.setHandleY(this, handleParams.y.toFloat() / screenHeightPx)
                    if (!draggedVertically && !openedByDrag) togglePanel()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, handleParams)
        handleView = view
    }

    private fun applyHandleAlpha(view: View) {
        val baseAlpha = SmartSidebarPrefs.getAlphaPercent(this) / 100f
        val recentPackage = LaunchHistoryStore.getRecent(this).firstOrNull()?.first
        val dimForGame = recentPackage != null && GameModeStore.isGame(this, recentPackage)
        view.alpha = if (dimForGame) (baseAlpha * 0.4f).coerceAtLeast(0.15f) else baseAlpha
    }

    private fun togglePanel() {
        if (panelView != null) closePanel() else openPanel()
    }

    // ---------------------------------------------------------------
    // Panel: the real content — favorites, tools, files, recent.
    // ---------------------------------------------------------------
    private fun openPanel() {
        if (panelView != null) return
        val isRight = SmartSidebarPrefs.isRightEdge(this)
        val panel = LayoutInflater.from(this).inflate(R.layout.overlay_sidebar_panel, null)
        ThemeManager.applyIosCard(panel, 0f)
        panel.alpha = SmartSidebarPrefs.getAlphaPercent(this) / 100f

        val title = panel.findViewById<android.widget.TextView>(R.id.sidebarTitle)
        title.setTextColor(ThemeManager.textPrimary(this))
        panel.findViewById<View>(R.id.sidebarSettingsBtn).setOnClickListener {
            startActivity(Intent(this, SmartSidebarSettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        panel.findViewById<View>(R.id.sidebarCloseBtn).setOnClickListener { closePanel() }

        setUpFavorites(panel)
        setUpTools(panel)
        setUpFilesRow(panel)
        setUpRecent(panel)
        setUpDragToClose(panel, isRight)

        val widthPx = (SmartSidebarPrefs.getPanelWidthDp(this) * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            widthPx,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            0, // focusable: the "add favorite" search box needs the keyboard
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or if (isRight) Gravity.END else Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        windowManager.addView(panel, params)
        panelView = panel

        if (PerformanceModeStore.animationsEnabled(this)) {
            panel.translationX = if (isRight) widthPx.toFloat() else -widthPx.toFloat()
            panel.animate().translationX(0f).setDuration(200).start()
        }
    }

    private fun closePanel() {
        val panel = panelView ?: return
        panelView = null
        if (PerformanceModeStore.animationsEnabled(this)) {
            val isRight = SmartSidebarPrefs.isRightEdge(this)
            val target = if (isRight) panel.width.toFloat() else -panel.width.toFloat()
            panel.animate().translationX(target).setDuration(160)
                .withEndAction { runCatching { windowManager.removeView(panel) } }
                .start()
        } else {
            runCatching { windowManager.removeView(panel) }
        }
    }

    /** Dragging the panel back toward the edge closes it — the spec's "swipe outward to close". */
    private fun setUpDragToClose(panel: View, isRight: Boolean) {
        var startX = 0f
        var startRawX = 0f
        panel.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = panel.translationX
                    startRawX = event.rawX
                    false // let children (buttons, lists) still receive this
                }
                MotionEvent.ACTION_MOVE -> {
                    val delta = event.rawX - startRawX
                    val outward = if (isRight) delta > 0 else delta < 0
                    if (outward) {
                        panel.translationX = delta
                        true
                    } else false
                }
                MotionEvent.ACTION_UP -> {
                    val threshold = panel.width * 0.3f
                    if (abs(panel.translationX) > threshold) {
                        closePanel()
                    } else {
                        panel.animate().translationX(0f).setDuration(120).start()
                    }
                    false
                }
                else -> false
            }
        }
    }

    private fun setUpFavorites(panel: View) {
        val favPairs = FavoritesStore.getFavorites(this)
        val favApps = favPairs.mapNotNull { (pkg, act) -> AppRepository.resolveApp(this, pkg, act) }.toMutableList()
        val list = panel.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.sidebarFavoritesList)
        list.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        val adapter = SidebarFavoriteAdapter(this, favApps, editMode = false) { app ->
            LaunchHistoryStore.recordLaunch(this, app.packageName, app.activityName)
            launchApp(app.packageName, app.activityName)
            closePanel()
        }
        list.adapter = adapter
        adapter.touchHelper.attachToRecyclerView(list)

        val editToggle = panel.findViewById<android.widget.TextView>(R.id.favEditToggle)
        editToggle.setTextColor(ThemeManager.accentColor(this))
        var editing = false
        editToggle.setOnClickListener {
            editing = !editing
            editToggle.text = if (editing) "Done" else "Edit"
            adapter.setEditMode(editing)
        }

        val addBtn = panel.findViewById<android.widget.TextView>(R.id.favAddBtn)
        addBtn.setTextColor(ThemeManager.accentColor(this))
        val pickerSection = panel.findViewById<View>(R.id.addPickerSection)
        val pickerSearch = panel.findViewById<android.widget.EditText>(R.id.addPickerSearch)
        val pickerList = panel.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.addPickerList)
        pickerList.layoutManager = GridLayoutManager(this, 4)

        fun onPicked(picked: com.sely.launcher.AppInfo) {
            FavoritesStore.addFavorite(this, picked.packageName, picked.activityName)
            pickerSection.visibility = View.GONE
            setUpFavorites(panel) // rebuild the favorites row with the new entry
        }

        fun refreshPicker(query: String) {
            val favPkgs = FavoritesStore.getFavorites(this).map { it.first }.toSet()
            val candidates = AppRepository.loadVisibleApps(this)
                .filterNot { it.packageName in favPkgs }
                .filter { query.isBlank() || it.label.lowercase().contains(query.lowercase()) }
            pickerList.adapter = SidebarAddPickerAdapter(this, candidates, ::onPicked)
        }

        pickerSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { refreshPicker(s?.toString().orEmpty()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        addBtn.setOnClickListener {
            val showing = pickerSection.visibility == View.VISIBLE
            if (showing) {
                pickerSection.visibility = View.GONE
            } else {
                pickerSection.visibility = View.VISIBLE
                pickerSearch.text = null
                refreshPicker("")
            }
        }
    }

    private fun setUpTools(panel: View) {
        val grid = panel.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.sidebarToolsGrid)
        grid.layoutManager = GridLayoutManager(this, 4)
        grid.adapter = ControlTileAdapter(this, buildTools(), iosStyle = true)
    }

    private fun buildTools(): List<ControlTile> = listOf(
        ControlTile("Screenshot", R.drawable.ic_sely_camera) {
            openActivity(com.sely.launcher.screenshotstudio.ScreenshotStudioActivity::class.java)
        },
        ControlTile("Screen Rec", R.drawable.ic_sely_record) {
            openActivity(com.sely.launcher.screenrecorder.ScreenRecorderActivity::class.java)
        },
        ControlTile("Flashlight", R.drawable.ic_sely_flashlight) { toggleFlashlight() },
        ControlTile("Calculator", R.drawable.ic_sely_settings) { openCalculator() },
        ControlTile("QR Scan", R.drawable.ic_sely_qr) {
            openActivity(com.sely.launcher.qrscanner.QrScannerActivity::class.java)
        },
        ControlTile("Camera", R.drawable.ic_sely_camera) { openCamera() },
        ControlTile("Clipboard", R.drawable.ic_sely_clipboard) {
            openActivity(com.sely.launcher.clipboard.ClipboardManagerActivity::class.java)
        }
    )

    private fun setUpFilesRow(panel: View) {
        panel.findViewById<android.widget.TextView>(R.id.sidebarFilesLabel).setTextColor(ThemeManager.textPrimary(this))
        panel.findViewById<View>(R.id.sidebarFilesRow).setOnClickListener {
            openActivity(com.sely.launcher.filehub.FileHubActivity::class.java)
        }
    }

    private fun setUpRecent(panel: View) {
        val recent = LaunchHistoryStore.getRecent(this)
            .mapNotNull { (pkg, act) -> AppRepository.resolveApp(this, pkg, act) }
        val list = panel.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.sidebarRecentList)
        val empty = panel.findViewById<android.widget.TextView>(R.id.sidebarRecentEmpty)
        empty.setTextColor(ThemeManager.textSecondary(this))
        empty.visibility = if (recent.isEmpty()) View.VISIBLE else View.GONE
        list.visibility = if (recent.isEmpty()) View.GONE else View.VISIBLE
        list.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        list.adapter = AppGridAdapter(this, recent, iosStyle = true)
    }

    // ---- real tool actions ----
    private fun openActivity(cls: Class<out android.app.Activity>) {
        closePanel()
        startActivity(Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun launchApp(packageName: String, activityName: String) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = android.content.ComponentName(packageName, activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open that app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleFlashlight() {
        val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cameraManager.setTorchMode(cameraId, torchOn)
        } catch (e: Exception) {
            Toast.makeText(this, "Flashlight unavailable: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCalculator() {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_APP_CALCULATOR)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            closePanel()
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "No calculator app found on this device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            closePanel()
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "No camera app found on this device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildNotification(): android.app.Notification {
        val stopIntent = Intent(this, SmartSidebarService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Sely Smart Sidebar is running")
            .setContentText("Drag the edge handle to open it · Tap Stop to turn off")
            .setSmallIcon(R.drawable.ic_sely_switch)
            .addAction(R.drawable.ic_sely_close, "Stop", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Smart Sidebar", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        panelView?.let { runCatching { windowManager.removeView(it) } }
        handleView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
        handleView = null
        SmartSidebarPrefs.setRunning(this, false)
    }
}

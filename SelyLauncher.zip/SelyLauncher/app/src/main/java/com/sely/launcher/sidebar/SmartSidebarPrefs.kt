package com.sely.launcher.sidebar

import android.content.Context

/**
 * Sely Smart Sidebar — customization + running state, same persisted-
 * SharedPreferences pattern as BubblePrefs (see bubble/BubblePrefs.kt).
 */
object SmartSidebarPrefs {
    private const val PREFS = "sely_smart_sidebar"
    private const val KEY_RUNNING = "running"
    private const val KEY_EDGE_RIGHT = "edge_right"
    private const val KEY_HANDLE_Y = "handle_y"
    private const val KEY_WIDTH_DP = "width_dp"
    private const val KEY_ALPHA_PERCENT = "alpha_percent"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun setRunning(context: Context, running: Boolean) =
        prefs(context).edit().putBoolean(KEY_RUNNING, running).apply()

    fun isRunning(context: Context) = prefs(context).getBoolean(KEY_RUNNING, false)

    /** true = right edge (default, matches ColorOS), false = left edge. */
    fun isRightEdge(context: Context) = prefs(context).getBoolean(KEY_EDGE_RIGHT, true)

    fun setRightEdge(context: Context, right: Boolean) =
        prefs(context).edit().putBoolean(KEY_EDGE_RIGHT, right).apply()

    /** Handle's vertical position, 0f (top) to 1f (bottom) of usable screen height. */
    fun getHandleY(context: Context) = prefs(context).getFloat(KEY_HANDLE_Y, 0.4f)

    fun setHandleY(context: Context, fraction: Float) =
        prefs(context).edit().putFloat(KEY_HANDLE_Y, fraction.coerceIn(0f, 1f)).apply()

    fun getPanelWidthDp(context: Context) = prefs(context).getInt(KEY_WIDTH_DP, 280)

    fun setPanelWidthDp(context: Context, dp: Int) =
        prefs(context).edit().putInt(KEY_WIDTH_DP, dp.coerceIn(220, 360)).apply()

    fun getAlphaPercent(context: Context) = prefs(context).getInt(KEY_ALPHA_PERCENT, 100)

    fun setAlphaPercent(context: Context, percent: Int) =
        prefs(context).edit().putInt(KEY_ALPHA_PERCENT, percent.coerceIn(40, 100)).apply()
}
